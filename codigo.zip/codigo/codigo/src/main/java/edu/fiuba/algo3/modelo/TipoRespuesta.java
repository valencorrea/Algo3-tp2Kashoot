package edu.fiuba.algo3.modelo;

public abstract class TipoRespuesta {

    public abstract boolean soyCorrecta();

    public abstract int getPuntos();


}
