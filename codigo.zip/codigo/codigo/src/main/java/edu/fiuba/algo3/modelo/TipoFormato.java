package edu.fiuba.algo3.modelo;

public abstract class TipoFormato {
    public abstract int calcularPuntaje(Respuesta unaRespuesta);
}
