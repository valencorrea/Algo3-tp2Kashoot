package edu.fiuba.algo3.modelo;

public abstract class TipoPregunta {
    public abstract int calcularPuntaje(Respuesta soyCorrecta);
}
