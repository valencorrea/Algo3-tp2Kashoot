package edu.fiuba.algo3.modelo;

import org.junit.jupiter.api.Test;

public class KahootTest {

    @Test
    public void jugadorRespondeVerdaderoFalso(){



    }

}
